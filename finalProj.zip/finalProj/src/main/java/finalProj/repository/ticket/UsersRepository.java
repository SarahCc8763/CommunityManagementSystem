package finalProj.repository.ticket;

import org.springframework.data.jpa.repository.JpaRepository;

import finalProj.domain.ticket.Users;

public interface UsersRepository extends JpaRepository<Users, Integer> {

}
